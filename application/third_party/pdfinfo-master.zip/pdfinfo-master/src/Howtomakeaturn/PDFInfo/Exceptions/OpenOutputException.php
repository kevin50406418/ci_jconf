<?php
namespace Howtomakeaturn\PDFInfo\Exceptions;

use \Exception;

class OpenOutputException extends Exception{};
