<?php
namespace Howtomakeaturn\PDFInfo\Exceptions;

use \Exception;

class PDFPermissionException extends Exception{};
