<?php
namespace Howtomakeaturn\PDFInfo\Exceptions;

use \Exception;

class OpenPDFException extends Exception{};
